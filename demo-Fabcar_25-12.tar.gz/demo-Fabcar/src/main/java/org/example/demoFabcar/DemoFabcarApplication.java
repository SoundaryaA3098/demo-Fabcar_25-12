package org.example.demoFabcar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFabcarApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFabcarApplication.class, args);
	}

}
